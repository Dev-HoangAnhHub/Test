import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  await prisma.region.createMany({
    data: [
      { code: 'VN', name: 'Vietnam', isDefault: true },
      { code: 'EN', name: 'English' },
      { code: 'GLOBAL', name: 'Global' },
    ],
    skipDuplicates: true,
  });

  await prisma.script.upsert({
    where: { name: 'demo-script' },
    update: {},
    create: {
      name: 'demo-script',
      displayName: 'Demo Script',
      description: 'Example script for key system testing',
      version: '1.0.0',
      freeEnabled: true,
      premiumEnabled: true,
      hwidEnabled: true,
      freeDurations: [120, 240, 720, 1440, 4020],
    },
  });

  await prisma.provider.upsert({
    where: { publicId: 'generic-dev' },
    update: {},
    create: {
      publicId: 'generic-dev',
      name: 'generic-dev',
      displayName: 'Generic Dev Provider',
      type: 'CALLBACK',
      region: 'GLOBAL',
      enabled: true,
      priority: 1,
    },
  });

  console.log('Seed completed');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
