import type { Request, Response, NextFunction } from 'express';
import { redis } from '../utils/redis.js';
import { AppError } from '../utils/errors.js';
import { hashIp } from '../utils/crypto.js';

interface RateLimitOptions {
  windowMs: number;
  max: number;
  keyPrefix: string;
}

export function createRateLimiter(opts: RateLimitOptions) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const ip = req.ip || req.socket.remoteAddress || 'unknown';
      const userPart = req.user?.id || 'anon';
      const key = `rl:${opts.keyPrefix}:${hashIp(ip)}:${userPart}`;

      const count = await redis.incr(key);
      if (count === 1) {
        await redis.pexpire(key, opts.windowMs);
      }

      const remaining = Math.max(0, opts.max - count);
      res.setHeader('X-RateLimit-Limit', String(opts.max));
      res.setHeader('X-RateLimit-Remaining', String(remaining));

      if (count > opts.max) {
        const ttl = await redis.pttl(key);
        res.setHeader('Retry-After', String(Math.ceil(ttl / 1000)));
        return next(new AppError('RATE_LIMITED', 'Too many requests', 429));
      }
      next();
    } catch {
      // Fail open if Redis is down (log in production)
      next();
    }
  };
}

export const freeStartLimiter = createRateLimiter({
  windowMs: 60_000,
  max: 10,
  keyPrefix: 'free-start',
});

export const claimLimiter = createRateLimiter({
  windowMs: 60_000,
  max: 20,
  keyPrefix: 'claim',
});

export const spinLimiter = createRateLimiter({
  windowMs: 60_000,
  max: 5,
  keyPrefix: 'spin',
});

export const chatLimiter = createRateLimiter({
  windowMs: 10_000,
  max: 15,
  keyPrefix: 'chat',
});

export const authLimiter = createRateLimiter({
  windowMs: 60_000,
  max: 30,
  keyPrefix: 'auth',
});
