import type { Request, Response, NextFunction } from 'express';
import { prisma } from '../utils/db.js';
import { hashValue } from '../utils/crypto.js';
import { AppError } from '../utils/errors.js';
import { config } from '../utils/config.js';
import type { Role } from '@prisma/client';

export interface AuthUser {
  id: string;
  email: string;
  role: Role;
  displayName: string | null;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      sessionId?: string;
    }
  }
}

const ROLE_RANK: Record<Role, number> = {
  GUEST: 0,
  USER: 1,
  STAFF: 2,
  MODERATOR: 3,
  MANAGER: 4,
  ADMIN: 5,
  OWNER: 6,
};

export async function loadSession(req: Request, _res: Response, next: NextFunction) {
  try {
    const raw = req.cookies?.session;
    if (!raw) return next();

    const tokenHash = hashValue(raw);
    const session = await prisma.session.findUnique({
      where: { tokenHash },
      include: { user: true },
    });

    if (!session || session.expiresAt < new Date()) {
      return next();
    }

    if (session.user.isBanned) {
      return next();
    }

    // Ensure owner role for configured admin emails
    let role = session.user.role;
    if (config.adminEmails.includes(session.user.email.toLowerCase()) && role !== 'OWNER') {
      await prisma.user.update({
        where: { id: session.user.id },
        data: { role: 'OWNER' },
      });
      role = 'OWNER';
    }

    req.user = {
      id: session.user.id,
      email: session.user.email,
      role,
      displayName: session.user.displayName,
    };
    req.sessionId = session.id;

    // Touch last active (fire-and-forget)
    prisma.session
      .update({ where: { id: session.id }, data: { lastActiveAt: new Date() } })
      .catch(() => {});

    next();
  } catch (e) {
    next(e);
  }
}

export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) {
    return next(new AppError('UNAUTHORIZED', 'Authentication required', 401));
  }
  next();
}

export function requireRole(...roles: Role[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AppError('UNAUTHORIZED', 'Authentication required', 401));
    }
    const userRank = ROLE_RANK[req.user.role] ?? 0;
    const minRank = Math.min(...roles.map((r) => ROLE_RANK[r] ?? 99));
    if (userRank < minRank) {
      return next(new AppError('FORBIDDEN', 'Insufficient permissions', 403));
    }
    next();
  };
}

export function requirePermission(check: (user: AuthUser) => boolean) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new AppError('UNAUTHORIZED', 'Authentication required', 401));
    }
    if (!check(req.user)) {
      return next(new AppError('FORBIDDEN', 'Insufficient permissions', 403));
    }
    next();
  };
}
