import { prisma } from '../utils/db.js';
import { generateKeyValue, hashHwid } from '../utils/crypto.js';
import { config } from '../utils/config.js';
import { AppError } from '../utils/errors.js';
import type { KeyType, KeyStatus } from '@prisma/client';
import { acquireLock, releaseLock } from '../utils/redis.js';

export async function createKey(params: {
  scriptId: string;
  userId?: string | null;
  type: KeyType;
  durationMinutes?: number | null;
  challengeId?: string | null;
  hwid?: string | null;
}): Promise<{ id: string; keyValue: string; expiresAt: Date | null }> {
  const lockKey = `key-create:${params.challengeId || params.userId || 'anon'}`;
  const token = await acquireLock(lockKey, 8000);
  if (!token) {
    throw new AppError('DUPLICATE_REQUEST', 'Request already in progress', 409);
  }

  try {
    // Prevent duplicate claim for same challenge
    if (params.challengeId) {
      const existing = await prisma.key.findUnique({
        where: { challengeId: params.challengeId },
      });
      if (existing) {
        return {
          id: existing.id,
          keyValue: existing.keyValue,
          expiresAt: existing.expiresAt,
        };
      }
    }

    let keyValue = generateKeyValue(config.key);
    // Extremely unlikely collision loop
    for (let i = 0; i < 5; i++) {
      const clash = await prisma.key.findUnique({ where: { keyValue } });
      if (!clash) break;
      keyValue = generateKeyValue(config.key);
    }

    const expiresAt =
      params.durationMinutes && params.durationMinutes > 0
        ? new Date(Date.now() + params.durationMinutes * 60_000)
        : null;

    const key = await prisma.key.create({
      data: {
        keyValue,
        type: params.type,
        status: 'ACTIVE',
        scriptId: params.scriptId,
        userId: params.userId || null,
        durationMinutes: params.durationMinutes ?? null,
        challengeId: params.challengeId || null,
        hwidHash: params.hwid ? hashHwid(params.hwid) : null,
        expiresAt,
      },
    });

    await prisma.keyHistory.create({
      data: {
        keyId: key.id,
        action: 'CREATED',
        actorId: params.userId || null,
        meta: { type: params.type, durationMinutes: params.durationMinutes },
      },
    });

    return { id: key.id, keyValue: key.keyValue, expiresAt: key.expiresAt };
  } finally {
    await releaseLock(lockKey, token);
  }
}

export async function verifyKey(params: {
  keyValue: string;
  hwid?: string;
  scriptId?: string;
}): Promise<{
  valid: boolean;
  status: KeyStatus;
  expiresAt: Date | null;
  scriptId: string;
  type: KeyType;
}> {
  const key = await prisma.key.findUnique({
    where: { keyValue: params.keyValue },
  });

  if (!key) {
    throw new AppError('INVALID_KEY', 'Key not found', 404);
  }

  if (params.scriptId && key.scriptId !== params.scriptId) {
    throw new AppError('INVALID_KEY', 'Key does not match script', 400);
  }

  if (key.status === 'BLACKLISTED') {
    throw new AppError('BLACKLISTED_KEY', 'Key is blacklisted', 403);
  }
  if (key.status === 'REVOKED') {
    throw new AppError('REVOKED_KEY', 'Key has been revoked', 403);
  }
  if (key.status === 'SUSPENDED') {
    throw new AppError('REVOKED_KEY', 'Key is suspended', 403);
  }

  if (key.expiresAt && key.expiresAt < new Date()) {
    if (key.status === 'ACTIVE') {
      await prisma.key.update({
        where: { id: key.id },
        data: { status: 'EXPIRED' },
      });
    }
    throw new AppError('EXPIRED_KEY', 'Key has expired', 403);
  }

  // HWID bind on first use
  if (key.hwidHash) {
    if (!params.hwid) {
      throw new AppError('HWID_MISMATCH', 'HWID required', 403);
    }
    if (hashHwid(params.hwid) !== key.hwidHash) {
      throw new AppError('HWID_MISMATCH', 'HWID does not match', 403);
    }
  } else if (params.hwid) {
    await prisma.key.update({
      where: { id: key.id },
      data: { hwidHash: hashHwid(params.hwid) },
    });
    await prisma.keyHistory.create({
      data: {
        keyId: key.id,
        action: 'HWID_BOUND',
        meta: {},
      },
    });
  }

  return {
    valid: true,
    status: key.status,
    expiresAt: key.expiresAt,
    scriptId: key.scriptId,
    type: key.type,
  };
}

export async function getGoogleBonusMinutes(durationMinutes: number): Promise<number> {
  const idx = config.freeDurations.indexOf(durationMinutes);
  if (idx === -1) return 0;
  return config.googleBonusMinutes[idx] ?? 0;
}
