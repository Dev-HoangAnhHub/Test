import { randomBytes } from 'crypto';
import { prisma } from '../utils/db.js';
import { AppError } from '../utils/errors.js';
import { acquireLock, releaseLock, idempotencyCheck } from '../utils/redis.js';
import { createKey, getGoogleBonusMinutes } from '../keys/keyService.js';
import { config } from '../utils/config.js';
import type { ChallengeState } from '@prisma/client';

const CHALLENGE_TTL_MS = 30 * 60 * 1000; // 30 minutes

export async function startFreeChallenge(params: {
  scriptId: string;
  durationMinutes: number;
  region?: string;
  providerId: string;
  userId?: string | null;
  anonymousSessionId?: string | null;
}): Promise<{
  challengeId: string;
  publicId: string;
  expiresAt: Date;
  redirectUrl: string | null;
}> {
  if (!config.freeDurations.includes(params.durationMinutes)) {
    throw new AppError('INVALID_CONFIG', 'Invalid duration', 400);
  }

  const script = await prisma.script.findFirst({
    where: { id: params.scriptId, enabled: true, emergencyLock: false },
  });
  if (!script) {
    throw new AppError('SCRIPT_DISABLED', 'Script not available', 404);
  }
  if (script.maintenance) {
    throw new AppError('MAINTENANCE', 'Script is under maintenance', 503);
  }
  if (!script.freeEnabled) {
    throw new AppError('FORBIDDEN', 'Free keys disabled for this script', 403);
  }

  const provider = await prisma.provider.findFirst({
    where: { id: params.providerId, enabled: true, circuitOpen: false },
  });
  if (!provider) {
    throw new AppError('PROVIDER_UNAVAILABLE', 'Provider not available', 503);
  }

  const nonce = randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + CHALLENGE_TTL_MS);

  const challenge = await prisma.challenge.create({
    data: {
      state: 'CREATED',
      nonce,
      providerId: provider.id,
      scriptId: script.id,
      durationMinutes: params.durationMinutes,
      userId: params.userId || null,
      anonymousSessionId: params.anonymousSessionId || null,
      expiresAt,
    },
  });

  // Generic adapter: for OWN_API / external we would call create endpoint here.
  // For foundation we return a verification page URL; real providers plug in via config.
  const redirectUrl = `${config.frontendUrl}/get-key/verify?c=${challenge.publicId}`;

  await prisma.challenge.update({
    where: { id: challenge.id },
    data: { state: 'REDIRECTED' },
  });

  return {
    challengeId: challenge.id,
    publicId: challenge.publicId,
    expiresAt,
    redirectUrl,
  };
}

/**
 * Mark challenge verified ONLY after trusted provider signal
 * (callback / webhook / verified API response). Never trust client.
 */
export async function markChallengeVerified(params: {
  publicId: string;
  providerId: string;
  externalToken?: string;
  externalId?: string;
  payload?: unknown;
  signatureValid: boolean;
}): Promise<void> {
  if (!params.signatureValid) {
    throw new AppError('INVALID_SIGNATURE', 'Invalid provider signature', 403);
  }

  const challenge = await prisma.challenge.findUnique({
    where: { publicId: params.publicId },
  });
  if (!challenge) {
    throw new AppError('NOT_FOUND', 'Challenge not found', 404);
  }
  if (challenge.providerId !== params.providerId) {
    throw new AppError('INVALID_PROVIDER', 'Provider mismatch', 400);
  }
  if (challenge.state === 'CLAIMED') {
    return; // idempotent
  }
  if (challenge.state === 'EXPIRED' || challenge.expiresAt < new Date()) {
    throw new AppError('CHALLENGE_EXPIRED', 'Challenge expired', 400);
  }
  if (challenge.state === 'VERIFIED') {
    return;
  }
  if (challenge.state !== 'CREATED' && challenge.state !== 'REDIRECTED') {
    throw new AppError('VERIFICATION_FAILED', 'Invalid challenge state', 400);
  }

  await prisma.challenge.update({
    where: { id: challenge.id },
    data: {
      state: 'VERIFIED',
      verifiedAt: new Date(),
      externalToken: params.externalToken || null,
      externalId: params.externalId || null,
      completionPayload: params.payload as object | undefined,
    },
  });
}

export async function claimKey(params: {
  publicId: string;
  userId?: string | null;
  idempotencyKey?: string;
}): Promise<{ keyValue: string; expiresAt: Date | null }> {
  if (params.idempotencyKey) {
    const first = await idempotencyCheck(`claim:${params.idempotencyKey}`, 86400);
    if (!first) {
      // Return existing key if already claimed under this idempotency key
      const existing = await prisma.challenge.findFirst({
        where: { publicId: params.publicId, state: 'CLAIMED' },
        include: { key: true },
      });
      if (existing?.key) {
        return { keyValue: existing.key.keyValue, expiresAt: existing.key.expiresAt };
      }
      throw new AppError('DUPLICATE_REQUEST', 'Duplicate claim', 409);
    }
  }

  const lockToken = await acquireLock(`claim:${params.publicId}`, 10000);
  if (!lockToken) {
    throw new AppError('DUPLICATE_REQUEST', 'Claim in progress', 409);
  }

  try {
    const challenge = await prisma.challenge.findUnique({
      where: { publicId: params.publicId },
      include: { key: true },
    });

    if (!challenge) {
      throw new AppError('NOT_FOUND', 'Challenge not found', 404);
    }
    if (challenge.state === 'CLAIMED' && challenge.key) {
      return { keyValue: challenge.key.keyValue, expiresAt: challenge.key.expiresAt };
    }
    if (challenge.state !== 'VERIFIED') {
      throw new AppError('VERIFICATION_FAILED', 'Challenge not verified yet', 400);
    }
    if (challenge.expiresAt < new Date()) {
      await prisma.challenge.update({
        where: { id: challenge.id },
        data: { state: 'EXPIRED' },
      });
      throw new AppError('CHALLENGE_EXPIRED', 'Challenge expired', 400);
    }

    // Ownership check: logged-in user must match if challenge was started by a user
    if (challenge.userId && params.userId && challenge.userId !== params.userId) {
      throw new AppError('FORBIDDEN', 'Challenge belongs to another user', 403);
    }

    let duration = challenge.durationMinutes;
    if (params.userId) {
      const bonus = await getGoogleBonusMinutes(duration);
      duration += bonus;
    }

    const key = await createKey({
      scriptId: challenge.scriptId,
      userId: params.userId || challenge.userId,
      type: 'FREE',
      durationMinutes: duration,
      challengeId: challenge.id,
    });

    await prisma.challenge.update({
      where: { id: challenge.id },
      data: { state: 'CLAIMED', claimedAt: new Date() },
    });

    return { keyValue: key.keyValue, expiresAt: key.expiresAt };
  } finally {
    await releaseLock(`claim:${params.publicId}`, lockToken);
  }
}

export async function getChallengeStatus(publicId: string) {
  const c = await prisma.challenge.findUnique({
    where: { publicId },
    select: {
      publicId: true,
      state: true,
      expiresAt: true,
      verifiedAt: true,
      claimedAt: true,
      durationMinutes: true,
      scriptId: true,
    },
  });
  if (!c) throw new AppError('NOT_FOUND', 'Challenge not found', 404);
  return c;
}
