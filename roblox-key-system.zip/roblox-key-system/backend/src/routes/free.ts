import { Router } from 'express';
import { z } from 'zod';
import {
  startFreeChallenge,
  claimKey,
  getChallengeStatus,
  markChallengeVerified,
} from '../challenges/challengeService.js';
import { freeStartLimiter, claimLimiter } from '../middleware/rateLimit.js';
import { AppError } from '../utils/errors.js';
import { prisma } from '../utils/db.js';
import { hmacSign, safeEqual } from '../utils/crypto.js';
import { config } from '../utils/config.js';

const router = Router();

const startSchema = z.object({
  scriptId: z.string().min(1),
  durationMinutes: z.number().int().positive(),
  region: z.string().optional(),
  providerId: z.string().min(1),
  anonymousSessionId: z.string().optional(),
});

router.post('/start', freeStartLimiter, async (req, res, next) => {
  try {
    const body = startSchema.parse(req.body);
    const result = await startFreeChallenge({
      ...body,
      userId: req.user?.id || null,
    });
    res.json({ success: true, data: result });
  } catch (e) {
    next(e);
  }
});

router.get('/challenge/:publicId', async (req, res, next) => {
  try {
    const data = await getChallengeStatus(req.params.publicId!);
    res.json({ success: true, data });
  } catch (e) {
    next(e);
  }
});

const claimSchema = z.object({
  publicId: z.string().min(1),
  idempotencyKey: z.string().optional(),
});

router.post('/claim', claimLimiter, async (req, res, next) => {
  try {
    const body = claimSchema.parse(req.body);
    const result = await claimKey({
      publicId: body.publicId,
      userId: req.user?.id || null,
      idempotencyKey: body.idempotencyKey,
    });
    res.json({ success: true, data: result });
  } catch (e) {
    next(e);
  }
});

/**
 * Provider callback / webhook endpoint.
 * Real providers must send signed payload. This handler validates signature
 * using provider credential secret (never trusts client flags).
 */
router.post('/callback/:providerPublicId', async (req, res, next) => {
  try {
    const provider = await prisma.provider.findFirst({
      where: { publicId: req.params.providerPublicId, enabled: true },
      include: { credentials: { where: { active: true }, take: 1 } },
    });
    if (!provider) {
      throw new AppError('INVALID_PROVIDER', 'Unknown provider', 404);
    }

    const challengePublicId =
      req.body.challenge_id || req.body.challengeId || req.query.challenge_id;
    if (!challengePublicId || typeof challengePublicId !== 'string') {
      throw new AppError('INVALID_CALLBACK', 'Missing challenge_id', 400);
    }

    // Signature validation (generic HMAC example)
    const signature =
      req.headers['x-signature'] ||
      req.headers['x-hub-signature-256'] ||
      req.body.signature;
    const secret =
      provider.credentials[0]?.apiTokenEnc || // in real system decrypt
      process.env.PROVIDER_CALLBACK_SECRET ||
      config.sessionSecret;

    const payload = JSON.stringify(req.body);
    const expected = hmacSign(payload, secret);
    const signatureValid =
      typeof signature === 'string' && safeEqual(signature.replace(/^sha256=/, ''), expected);

    // For development without real provider secrets, allow only if NODE_ENV=development
    // and a special header is present (remove in production)
    const devBypass =
      config.nodeEnv === 'development' &&
      req.headers['x-dev-verify'] === 'true';

    await markChallengeVerified({
      publicId: challengePublicId,
      providerId: provider.id,
      externalToken: req.body.token,
      externalId: req.body.external_id,
      payload: req.body,
      signatureValid: signatureValid || devBypass,
    });

    res.json({ success: true });
  } catch (e) {
    next(e);
  }
});

export default router;
