import { Router } from 'express';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { randomBytes } from 'crypto';
import { prisma } from '../utils/db.js';
import { config } from '../utils/config.js';
import { hashValue } from '../utils/crypto.js';
import { requireAuth, loadSession } from '../middleware/auth.js';
import { authLimiter } from '../middleware/rateLimit.js';
import { redis } from '../utils/redis.js';
import { AppError } from '../utils/errors.js';

const router = Router();

if (config.google.clientId && config.google.clientSecret) {
  passport.use(
    new GoogleStrategy(
      {
        clientID: config.google.clientId,
        clientSecret: config.google.clientSecret,
        callbackURL: config.google.callbackUrl,
      },
      async (_accessToken, _refreshToken, profile, done) => {
        try {
          const email = profile.emails?.[0]?.value;
          if (!email) return done(new Error('No email from Google'));

          let user = await prisma.user.findUnique({ where: { email } });
          const isOwner = config.adminEmails.includes(email.toLowerCase());

          if (!user) {
            user = await prisma.user.create({
              data: {
                googleId: profile.id,
                email,
                displayName: profile.displayName || email.split('@')[0],
                avatarUrl: profile.photos?.[0]?.value,
                role: isOwner ? 'OWNER' : 'USER',
                lastLoginAt: new Date(),
              },
            });
          } else {
            user = await prisma.user.update({
              where: { id: user.id },
              data: {
                googleId: profile.id,
                displayName: profile.displayName || user.displayName,
                avatarUrl: profile.photos?.[0]?.value || user.avatarUrl,
                lastLoginAt: new Date(),
                role: isOwner ? 'OWNER' : user.role,
              },
            });
          }
          done(null, user);
        } catch (e) {
          done(e as Error);
        }
      },
    ),
  );
}

router.get('/google', authLimiter, async (req, res, next) => {
  if (!config.google.clientId) {
    return next(new AppError('INVALID_CONFIG', 'Google OAuth not configured', 503));
  }
  const state = randomBytes(24).toString('hex');
  await redis.setex(`oauth:state:${state}`, 600, '1');
  passport.authenticate('google', {
    scope: ['profile', 'email'],
    state,
    session: false,
  })(req, res, next);
});

router.get(
  '/google/callback',
  authLimiter,
  async (req, res, next) => {
    const state = req.query.state as string;
    if (!state) {
      return res.redirect(`${config.frontendUrl}/auth/error?code=INVALID_STATE`);
    }
    const exists = await redis.get(`oauth:state:${state}`);
    if (!exists) {
      return res.redirect(`${config.frontendUrl}/auth/error?code=INVALID_STATE`);
    }
    await redis.del(`oauth:state:${state}`);
    next();
  },
  passport.authenticate('google', {
    session: false,
    failureRedirect: `${config.frontendUrl}/auth/error`,
  }),
  async (req, res) => {
    const user = req.user as { id: string };
    const rawToken = randomBytes(32).toString('hex');
    const tokenHash = hashValue(rawToken);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    await prisma.session.create({
      data: {
        userId: user.id,
        tokenHash,
        userAgent: req.headers['user-agent']?.slice(0, 512),
        expiresAt,
      },
    });

    res.cookie('session', rawToken, {
      httpOnly: true,
      secure: config.cookie.secure,
      sameSite: config.cookie.sameSite,
      maxAge: 30 * 24 * 60 * 60 * 1000,
      path: '/',
    });

    res.redirect(`${config.frontendUrl}/dashboard`);
  },
);

router.post('/logout', requireAuth, async (req, res, next) => {
  try {
    if (req.sessionId) {
      await prisma.session.delete({ where: { id: req.sessionId } }).catch(() => {});
    }
    res.clearCookie('session', { path: '/' });
    res.json({ success: true });
  } catch (e) {
    next(e);
  }
});

router.post('/logout-all', requireAuth, async (req, res, next) => {
  try {
    await prisma.session.deleteMany({ where: { userId: req.user!.id } });
    res.clearCookie('session', { path: '/' });
    res.json({ success: true });
  } catch (e) {
    next(e);
  }
});

router.get('/me', loadSession, (req, res) => {
  if (!req.user) {
    return res.json({ success: true, data: null });
  }
  res.json({
    success: true,
    data: {
      id: req.user.id,
      email: req.user.email,
      role: req.user.role,
      displayName: req.user.displayName,
    },
  });
});

router.get('/me/sessions', requireAuth, async (req, res, next) => {
  try {
    const sessions = await prisma.session.findMany({
      where: { userId: req.user!.id },
      select: {
        id: true,
        userAgent: true,
        createdAt: true,
        lastActiveAt: true,
        expiresAt: true,
      },
      orderBy: { lastActiveAt: 'desc' },
    });
    res.json({ success: true, data: sessions });
  } catch (e) {
    next(e);
  }
});

export default router;
