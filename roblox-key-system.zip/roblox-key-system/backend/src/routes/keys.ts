import { Router } from 'express';
import { z } from 'zod';
import { verifyKey } from '../keys/keyService.js';
import { prisma } from '../utils/db.js';
import { requireAuth } from '../middleware/auth.js';
import { createRateLimiter } from '../middleware/rateLimit.js';

const router = Router();
const verifyLimiter = createRateLimiter({ windowMs: 60_000, max: 60, keyPrefix: 'key-verify' });

const verifySchema = z.object({
  key: z.string().min(1),
  hwid: z.string().optional(),
  scriptId: z.string().optional(),
});

router.post('/verify', verifyLimiter, async (req, res, next) => {
  try {
    const body = verifySchema.parse(req.body);
    const result = await verifyKey({
      keyValue: body.key,
      hwid: body.hwid,
      scriptId: body.scriptId,
    });
    res.json({ success: true, data: result });
  } catch (e) {
    next(e);
  }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const keys = await prisma.key.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
      select: {
        id: true,
        keyValue: true,
        type: true,
        status: true,
        expiresAt: true,
        createdAt: true,
        scriptId: true,
        hwidHash: true,
      },
    });
    res.json({ success: true, data: keys });
  } catch (e) {
    next(e);
  }
});

export default router;
