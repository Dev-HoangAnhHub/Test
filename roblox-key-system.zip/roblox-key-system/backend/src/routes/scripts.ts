import { Router } from 'express';
import { prisma } from '../utils/db.js';
import { AppError } from '../utils/errors.js';

const router = Router();

/** Public config for Roblox scripts – never includes secrets */
router.get('/config', async (req, res, next) => {
  try {
    const name = (req.query.name as string) || (req.query.script as string);
    if (!name) {
      throw new AppError('INVALID_CONFIG', 'script name required', 400);
    }

    const script = await prisma.script.findFirst({
      where: { name, enabled: true },
    });

    if (!script) {
      throw new AppError('NOT_FOUND', 'Script not found', 404);
    }

    res.json({
      success: true,
      data: {
        enabled: script.enabled && !script.emergencyLock,
        maintenance: script.maintenance,
        key_required: script.keyRequired,
        version: script.version,
        minimum_version: script.minVersion,
        free_enabled: script.freeEnabled,
        premium_enabled: script.premiumEnabled,
        hwid_enabled: script.hwidEnabled,
      },
    });
  } catch (e) {
    next(e);
  }
});

router.get('/', async (_req, res, next) => {
  try {
    const scripts = await prisma.script.findMany({
      where: { enabled: true },
      select: {
        id: true,
        name: true,
        displayName: true,
        description: true,
        logoUrl: true,
        freeEnabled: true,
        premiumEnabled: true,
        freeDurations: true,
        maintenance: true,
      },
    });
    res.json({ success: true, data: scripts });
  } catch (e) {
    next(e);
  }
});

export default router;
