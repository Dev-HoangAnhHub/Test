import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import passport from 'passport';
import { config } from './utils/config.js';
import { loadSession } from './middleware/auth.js';
import { AppError, errorResponse } from './utils/errors.js';
import { redis } from './utils/redis.js';
import { prisma } from './utils/db.js';

import authRoutes from './routes/auth.js';
import freeRoutes from './routes/free.js';
import keyRoutes from './routes/keys.js';
import scriptRoutes from './routes/scripts.js';

const app = express();

app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(
  cors({
    origin: config.frontendUrl,
    credentials: true,
  }),
);
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use(passport.initialize());
app.use(loadSession);

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', ts: new Date().toISOString() });
});

app.get('/ready', async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    const pong = await redis.ping();
    if (pong !== 'PONG') throw new Error('redis');
    res.json({ status: 'ready' });
  } catch {
    res.status(503).json({ status: 'not_ready' });
  }
});

app.use('/auth', authRoutes);
app.use('/api/free', freeRoutes);
app.use('/api/key', keyRoutes);
app.use('/api/script', scriptRoutes);

// 404
app.use((_req, res) => {
  res.status(404).json(errorResponse('NOT_FOUND', 'Not found'));
});

// Error handler – never leak stack
app.use(
  (
    err: unknown,
    _req: express.Request,
    res: express.Response,
    _next: express.NextFunction,
  ) => {
    if (err instanceof AppError) {
      return res.status(err.status).json(errorResponse(err.code, err.message));
    }
    if (err && typeof err === 'object' && 'name' in err && (err as { name: string }).name === 'ZodError') {
      return res.status(400).json(errorResponse('INVALID_CONFIG', 'Validation failed'));
    }
    console.error('[error]', err);
    res.status(500).json(errorResponse('INTERNAL_ERROR', 'Internal server error'));
  },
);

async function main() {
  await redis.connect().catch(() => {
    console.warn('Redis connect deferred');
  });
  app.listen(config.port, () => {
    console.log(`Backend listening on :${config.port}`);
  });
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
