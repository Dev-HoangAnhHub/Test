import Redis from 'ioredis';
import { config } from './config.js';

export const redis = new Redis(config.redisUrl, {
  maxRetriesPerRequest: 3,
  lazyConnect: true,
});

export async function acquireLock(key: string, ttlMs = 10000): Promise<string | null> {
  const token = `${Date.now()}-${Math.random()}`;
  const ok = await redis.set(`lock:${key}`, token, 'PX', ttlMs, 'NX');
  return ok === 'OK' ? token : null;
}

export async function releaseLock(key: string, token: string): Promise<void> {
  const script = `
    if redis.call("get", KEYS[1]) == ARGV[1] then
      return redis.call("del", KEYS[1])
    else
      return 0
    end
  `;
  await redis.eval(script, 1, `lock:${key}`, token);
}

export async function idempotencyCheck(key: string, ttlSec = 86400): Promise<boolean> {
  const ok = await redis.set(`idem:${key}`, '1', 'EX', ttlSec, 'NX');
  return ok === 'OK';
}
