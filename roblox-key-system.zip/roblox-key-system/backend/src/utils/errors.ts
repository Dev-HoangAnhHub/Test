export class AppError extends Error {
  constructor(
    public code: string,
    message: string,
    public status = 400,
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export function errorResponse(code: string, message: string) {
  return { success: false, error: code, message };
}
