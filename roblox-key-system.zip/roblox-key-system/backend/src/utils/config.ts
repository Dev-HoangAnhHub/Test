import 'dotenv/config';

function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env: ${name}`);
  return v;
}

export const config = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT || '3001', 10),
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:3000',
  apiBaseUrl: process.env.API_BASE_URL || 'http://localhost:3001',
  databaseUrl: required('DATABASE_URL'),
  redisUrl: process.env.REDIS_URL || 'redis://localhost:6379',
  sessionSecret: required('SESSION_SECRET'),
  encryptionKey: process.env.ENCRYPTION_KEY || '',
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID || '',
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || '',
    callbackUrl: process.env.GOOGLE_CALLBACK_URL || 'http://localhost:3001/auth/google/callback',
  },
  adminEmails: (process.env.ADMIN_EMAILS || 'mqrauma36@gmail.com')
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean),
  cookie: {
    secure: process.env.COOKIE_SECURE !== 'false',
    sameSite: (process.env.COOKIE_SAMESITE || 'lax') as 'lax' | 'strict' | 'none',
  },
  key: {
    prefix: process.env.KEY_PREFIX || 'NOVA',
    groupLength: parseInt(process.env.KEY_GROUP_LENGTH || '4', 10),
    groupCount: parseInt(process.env.KEY_GROUP_COUNT || '3', 10),
    separator: process.env.KEY_SEPARATOR || '-',
  },
  freeDurations: (process.env.FREE_DURATIONS || '120,240,720,1440,4020')
    .split(',')
    .map((n) => parseInt(n.trim(), 10)),
  googleBonusMinutes: (process.env.GOOGLE_BONUS_MINUTES || '30,30,30,180,180')
    .split(',')
    .map((n) => parseInt(n.trim(), 10)),
};
