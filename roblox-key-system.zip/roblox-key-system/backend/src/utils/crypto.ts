import { createHash, createHmac, randomBytes, timingSafeEqual } from 'crypto';

const SAFE_CHARSET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no O0I1L

export function secureRandomString(length: number, charset = SAFE_CHARSET): string {
  const bytes = randomBytes(length);
  let result = '';
  for (let i = 0; i < length; i++) {
    result += charset[bytes[i]! % charset.length];
  }
  return result;
}

export function generateKeyValue(opts: {
  prefix: string;
  groupLength: number;
  groupCount: number;
  separator: string;
}): string {
  const groups: string[] = [];
  for (let i = 0; i < opts.groupCount; i++) {
    groups.push(secureRandomString(opts.groupLength));
  }
  return `${opts.prefix}${opts.separator}${groups.join(opts.separator)}`;
}

export function hashValue(value: string, salt = ''): string {
  return createHash('sha256').update(salt + value).digest('hex');
}

export function hmacSign(payload: string, secret: string): string {
  return createHmac('sha256', secret).update(payload).digest('hex');
}

export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  try {
    return timingSafeEqual(Buffer.from(a), Buffer.from(b));
  } catch {
    return false;
  }
}

export function hashIp(ip: string): string {
  return hashValue(ip, 'ip-salt-v1');
}

export function hashHwid(hwid: string): string {
  return hashValue(hwid, 'hwid-salt-v1');
}
