# Architecture Overview

## Core flows implemented

### Free key

1. Client selects script, duration, region, provider  
2. `POST /api/free/start` → creates Challenge (CREATED → REDIRECTED)  
3. User completes external provider  
4. Provider hits `POST /api/free/callback/:providerPublicId` with signature  
5. Server marks Challenge VERIFIED (only if signature valid)  
6. User `POST /api/free/claim` → Key created, Challenge CLAIMED  

Returning to the site without a verified challenge never yields a key.

### Key verify (Roblox)

`POST /api/key/verify` with key + optional HWID.  
First successful verify with HWID binds the hash.

### Auth

Google OAuth with state stored in Redis, session cookie HttpOnly, role elevation for ADMIN_EMAILS only on server.

## Extending providers

Use `Provider` + `ProviderCredential` models. Implement adapters under `backend/src/providers/` that:

- Call create short URL  
- Validate callback/webhook signatures  
- Map response fields via `responseMapping` JSON  

Never trust `success: true` from the client.

## Remaining modules (structure ready)

Chat (WebSocket), Spin, Referral, Campaign, full Admin UI, 2FA, Analytics dashboards — follow the same patterns: server authz, idempotency, audit, rate limits.
