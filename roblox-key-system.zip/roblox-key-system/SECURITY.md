# Security Policy

## Reporting

Report vulnerabilities privately to the repository owner. Do not open public issues for security flaws.

## Principles

- All authorization is enforced server-side.
- Provider completion is only accepted via signed callback / webhook / verified API response.
- Secrets (API keys, OAuth secrets, session tokens) are never returned to the client or logged.
- Rate limiting, idempotency keys, and distributed locks protect claim / spin / callback endpoints.
- SSRF protections apply to all outbound HTTP calls to providers.
- HWID is stored only as a hash.
- Admin role elevation for configured emails happens only on the server.

## Secrets

Never commit `.env` or credential files. Use environment variables or a secret manager in production.
