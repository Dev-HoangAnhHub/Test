'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import clsx from 'clsx';

const links = [
  { href: '/', label: 'Home' },
  { href: '/get-key', label: 'Get Key' },
  { href: '/dashboard', label: 'Dashboard' },
  { href: '/lucky-spin', label: 'Spin' },
  { href: '/chat', label: 'Chat' },
];

export function Nav() {
  const path = usePathname();
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="text-lg font-bold tracking-tight">
          <span className="text-accent">Nova</span> Keys
        </Link>
        <nav className="hidden gap-1 md:flex">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={clsx(
                'rounded-lg px-3 py-1.5 text-sm transition',
                path === l.href ? 'bg-accent/20 text-accent' : 'text-muted hover:text-white',
              )}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <a href="/auth/google" className="btn-primary text-sm">
          Login with Google
        </a>
      </div>
      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 flex border-t border-border bg-card/95 backdrop-blur md:hidden">
        {links.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className={clsx(
              'flex-1 py-3 text-center text-xs',
              path === l.href ? 'text-accent' : 'text-muted',
            )}
          >
            {l.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
