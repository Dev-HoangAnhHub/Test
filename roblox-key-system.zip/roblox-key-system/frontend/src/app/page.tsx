import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="text-center pt-10 pb-6">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
          Premium <span className="text-accent">Key System</span>
        </h1>
        <p className="mt-4 text-muted max-w-xl mx-auto">
          Secure free & premium keys, HWID binding, multi-provider verification, and real-time
          management — built for production.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/get-key" className="btn-primary px-6">
            Get Free Key
          </Link>
          <a href="/auth/google" className="btn-ghost px-6">
            Sign in with Google
          </a>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[
          {
            title: 'Secure Verification',
            desc: 'Provider callback / webhook / API required. Returning to the site alone never grants a key.',
          },
          {
            title: 'HWID + Anti-Abuse',
            desc: 'Hashed HWID bind, rate limits, idempotency, race-condition locks.',
          },
          {
            title: 'Multi-Provider',
            desc: 'Generic adapter for LootLabs, Linkvertise, Work.ink, OWN_API and more.',
          },
          {
            title: 'Google Bonus',
            desc: 'Logged-in users receive extra duration on free keys (server-side).',
          },
          {
            title: 'RBAC & Audit',
            desc: 'Staff → Owner roles with server-side permission checks and audit logs.',
          },
          {
            title: 'Mobile Ready',
            desc: 'Responsive dark SaaS UI optimized for Android, iOS and desktop.',
          },
        ].map((f) => (
          <div key={f.title} className="card">
            <h3 className="font-semibold text-accent2">{f.title}</h3>
            <p className="mt-2 text-sm text-muted">{f.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
