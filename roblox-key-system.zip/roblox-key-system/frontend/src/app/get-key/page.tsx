'use client';

import { useEffect, useState } from 'react';

type Script = {
  id: string;
  name: string;
  displayName: string;
  freeDurations: number[];
  maintenance: boolean;
};

type Provider = { id: string; displayName: string };

const DURATIONS = [
  { min: 120, label: '2 hours' },
  { min: 240, label: '4 hours' },
  { min: 720, label: '12 hours' },
  { min: 1440, label: '24 hours' },
  { min: 4020, label: '67 hours' },
];

export default function GetKeyPage() {
  const [scripts, setScripts] = useState<Script[]>([]);
  const [scriptId, setScriptId] = useState('');
  const [duration, setDuration] = useState(120);
  const [providerId, setProviderId] = useState('');
  const [providers] = useState<Provider[]>([
    { id: 'generic-dev', displayName: 'Generic Dev Provider' },
  ]);
  const [step, setStep] = useState<'select' | 'redirect' | 'claim' | 'done'>('select');
  const [publicId, setPublicId] = useState('');
  const [keyValue, setKeyValue] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetch('/api/script')
      .then((r) => r.json())
      .then((j) => {
        if (j.success) {
          setScripts(j.data);
          if (j.data[0]) setScriptId(j.data[0].id);
        }
      })
      .catch(() => setError('Failed to load scripts'));
  }, []);

  async function start() {
    setError('');
    setLoading(true);
    try {
      // Resolve provider id from seed publicId or real list later
      const res = await fetch('/api/free/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          scriptId,
          durationMinutes: duration,
          providerId: providerId || 'generic-dev', // will be replaced by real DB id
          region: 'GLOBAL',
        }),
      });
      const j = await res.json();
      if (!j.success) throw new Error(j.message || j.error);
      setPublicId(j.data.publicId);
      setStep('redirect');
      // In production open j.data.redirectUrl (external provider)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Start failed');
    } finally {
      setLoading(false);
    }
  }

  async function claim() {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/free/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          publicId,
          idempotencyKey: `claim-${publicId}`,
        }),
      });
      const j = await res.json();
      if (!j.success) throw new Error(j.message || j.error);
      setKeyValue(j.data.keyValue);
      setStep('done');
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Claim failed — verify with provider first');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Get Free Key</h1>

      {error && (
        <div className="rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {error}
        </div>
      )}

      {step === 'select' && (
        <div className="card space-y-4">
          <div>
            <label className="text-sm text-muted">Script</label>
            <select
              className="mt-1 w-full rounded-xl border border-border bg-background px-3 py-2"
              value={scriptId}
              onChange={(e) => setScriptId(e.target.value)}
            >
              {scripts.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.displayName}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-sm text-muted">Duration</label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {DURATIONS.map((d) => (
                <button
                  key={d.min}
                  type="button"
                  onClick={() => setDuration(d.min)}
                  className={`rounded-xl border px-3 py-2 text-sm ${
                    duration === d.min
                      ? 'border-accent bg-accent/20 text-accent'
                      : 'border-border hover:border-accent/50'
                  }`}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-sm text-muted">Provider</label>
            <select
              className="mt-1 w-full rounded-xl border border-border bg-background px-3 py-2"
              value={providerId}
              onChange={(e) => setProviderId(e.target.value)}
            >
              <option value="">Select provider</option>
              {providers.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.displayName}
                </option>
              ))}
            </select>
          </div>
          <button className="btn-primary w-full" disabled={loading || !scriptId} onClick={start}>
            {loading ? 'Creating challenge…' : 'Continue'}
          </button>
        </div>
      )}

      {step === 'redirect' && (
        <div className="card space-y-4 text-center">
          <p className="text-muted text-sm">
            Challenge created. Complete the provider link, then return and claim.
            <br />
            <span className="text-xs">Challenge: {publicId}</span>
          </p>
          <p className="text-xs text-amber-400">
            In production this opens the external shortener. Key is only issued after server-side
            verification (callback / webhook / API).
          </p>
          <button className="btn-primary w-full" onClick={() => setStep('claim')}>
            I completed the provider
          </button>
        </div>
      )}

      {step === 'claim' && (
        <div className="card space-y-4 text-center">
          <p className="text-muted text-sm">Checking verification status…</p>
          <button className="btn-primary w-full" disabled={loading} onClick={claim}>
            {loading ? 'Claiming…' : 'Claim Key'}
          </button>
        </div>
      )}

      {step === 'done' && (
        <div className="card space-y-4 text-center">
          <p className="text-accent2 font-medium">Key ready</p>
          <code className="block rounded-xl bg-black/40 px-4 py-3 text-lg tracking-wider">
            {keyValue}
          </code>
          <button
            className="btn-ghost w-full"
            onClick={() => navigator.clipboard.writeText(keyValue)}
          >
            Copy
          </button>
        </div>
      )}
    </div>
  );
}
