export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="card">
          <h2 className="font-semibold">My Keys</h2>
          <p className="mt-2 text-sm text-muted">Login required. View and copy your active keys.</p>
        </div>
        <div className="card">
          <h2 className="font-semibold">Notifications</h2>
          <p className="mt-2 text-sm text-muted">Key expiry, spin availability, system alerts.</p>
        </div>
        <div className="card">
          <h2 className="font-semibold">Lucky Spin</h2>
          <p className="mt-2 text-sm text-muted">1 spin / 24h. Server-side random + pity.</p>
        </div>
        <div className="card">
          <h2 className="font-semibold">Account</h2>
          <p className="mt-2 text-sm text-muted">Sessions, logout all, referral code.</p>
        </div>
      </div>
    </div>
  );
}
