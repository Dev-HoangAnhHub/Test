import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        background: '#0a0a0f',
        card: '#12121a',
        border: '#1e1e2e',
        accent: '#7c5cff',
        accent2: '#00d4aa',
        muted: '#8b8b9e',
      },
      boxShadow: {
        glow: '0 0 20px rgba(124, 92, 255, 0.25)',
      },
    },
  },
  plugins: [],
};
export default config;
