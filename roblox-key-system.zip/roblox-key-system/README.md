# Roblox Script Key System

Production-ready foundation for a secure Roblox Script Key Management platform.

**Security-first • Server-side authorization • Race-condition safe • Provider verification required**

## Architecture

```
CDN/WAF → Reverse Proxy → Application
                           ├── Redis (sessions, rate-limit, cache, presence)
                           ├── PostgreSQL
                           ├── WebSocket (chat)
                           └── External Providers (API / Callback / Webhook)
```

```
roblox-key-system/
├── frontend/          # Next.js App Router + Tailwind (Premium dark SaaS UI)
├── backend/           # Node.js + Express + TypeScript + Prisma
├── database/          # Migrations & seed
├── tests/
├── docs/
├── scripts/
├── .github/workflows/
├── docker-compose.yml
├── Dockerfile
├── .env.example
└── README.md
```

## Features Implemented (Core)

- Google OAuth (state, CSRF, secure cookies, session rotation)
- Role-based access (GUEST → OWNER) – **server-side only**
- Free Key flow: Script → Duration → Region → Provider → Challenge → Verify → Claim
- Challenge states + single-use + nonce + expiration
- Generic Provider Adapter (OWN_API, CALLBACK, WEBHOOK, API_VERIFY, MULTI_STEP, MANUAL)
- Key engine (secure random, configurable format, no predictable chars)
- HWID bind (hashed)
- Rate limiting (IP / User / Endpoint)
- Idempotency keys for claim / spin / callback
- SSRF protection on external calls
- Audit log structure
- Circuit breaker + health skeleton
- Docker + CI skeleton
- Mobile-responsive foundation UI

## Not Fully Implemented (Structure Ready)

Full Chat (WebSocket), Lucky Spin + Pity, Referral, Campaign, 2FA TOTP, full Admin panels, Analytics dashboards, multi-step UI, etc.  
These modules have folders, Prisma models, and route stubs. Extend following the same security patterns.

## Requirements

- Node.js 20+
- PostgreSQL 15+
- Redis 7+
- Docker (optional)

## Quick Start

```bash
cp .env.example .env
# Edit .env with real values (never commit secrets)

docker compose up -d postgres redis
cd backend && npm i && npx prisma migrate dev && npm run dev
cd frontend && npm i && npm run dev
```

## Environment

See `.env.example`. Required:

- `DATABASE_URL`
- `REDIS_URL`
- `SESSION_SECRET` (long random)
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`
- `ADMIN_EMAILS=mqrauma36@gmail.com`
- `ENCRYPTION_KEY` (32-byte base64 for credential encryption)

## Security Notes

- Never trust client-sent role / duration / script_id / success flags
- Provider completion **must** come from callback / webhook / verified API response
- Returning to the site alone does **not** grant a key
- All admin mutations go through permission checks + audit
- Secrets are never logged or returned to frontend

## License

MIT (or change as needed)

## Owner

Admin emails default: `mqrauma36@gmail.com` (server-side only)
